package client;

import ui.Dialogs;
import ui.WelcomeScreen;
import ui.Widgets;

import javax.swing.*;
import java.awt.*;

/** The in-game frame. All the game logic lives in {@link GameScreen}. */
public class GameWindow extends JFrame {

    private final GameScreen screen;
    private final String playerName;
    private final WelcomeScreen origin;      // start screen that is hidden (not closed) while we connect
    private boolean originAlive;
    private boolean leaving;

    public GameWindow(String playerName) {
        this(playerName, "QUICK", "", null);
    }

    public GameWindow(String playerName, String roomAction, String roomCode) {
        this(playerName, roomAction, roomCode, null);
    }

    public GameWindow(String playerName, String roomAction, String roomCode, WelcomeScreen origin) {
        this.playerName = playerName;
        this.origin = origin;
        this.originAlive = origin != null;

        Widgets.installDefaults();
        setTitle("DOODLES - " + playerName);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1240, 780));
        setSize(1420, 880);
        setLocationRelativeTo(null);

        screen = new GameScreen(playerName, roomAction, roomCode);
        setContentPane(screen.root());
        setGlassPane(screen.toasts());
        screen.toasts().setVisible(true);
        screen.setHost(new GameScreen.Host() {
            @Override public void roomEntered() { showGame(); }
            @Override public void exitToMenu() { backToMenu(); }
        });

        String problem = screen.connect();
        if (problem != null) {
            Dialogs.message(originAlive ? origin : null, "Can't connect", problem, Dialogs.Kind.ERROR);
            backToMenu();
            return;
        }
        // safety net: if the server never answers, show the window anyway
        javax.swing.Timer fallback = new javax.swing.Timer(8000, e -> { if (!leaving) showGame(); });
        fallback.setRepeats(false);
        fallback.start();
    }

    /** The game window stays hidden until we really are inside a room. */
    private void showGame() {
        if (!isVisible()) setVisible(true);
        if (originAlive) {
            originAlive = false;
            origin.dispose();
        }
    }

    private void backToMenu() {
        SwingUtilities.invokeLater(() -> {
            if (leaving) return;
            leaving = true;
            if (originAlive) {
                originAlive = false;
                origin.reveal();
            } else {
                new WelcomeScreen(playerName).setVisible(true);
            }
            dispose();
        });
    }

    @Override
    public void dispose() {
        if (screen != null) screen.shutdown();
        super.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameWindow window = new GameWindow("TestPlayer");
            window.setVisible(true);
        });
    }
}
