package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ChatMessageDAO {

    public static void saveMessage(
            int gameId,
            int playerId,
            String message
    ) {

        String sql =
                "INSERT INTO chat_messages " +
                        "(game_id, player_id, message) " +
                        "VALUES (?, ?, ?)";

        try (
                Connection connection =
                        DataBaseConnection.connect()
        ) {

            if (connection == null) {
                return;
            }

            try (
                    PreparedStatement statement =
                            connection.prepareStatement(sql)
            ) {

                statement.setInt(
                        1,
                        gameId
                );

                statement.setInt(
                        2,
                        playerId
                );

                statement.setString(
                        3,
                        message
                );

                statement.executeUpdate();
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error saving chat message."
            );

            e.printStackTrace();
        }
    }
}