package database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DrawingDAO {

    public static void saveDrawing(
            int gameId,
            int playerId,
            String drawingData
    ) {

        String sql =
                "INSERT INTO drawings " +
                        "(game_id, player_id, drawing_data) " +
                        "VALUES (?, ?, ?)";

        try (
                Connection connection =
                        DataBaseConnection.connect()
        ) {

            if (connection == null) {
                return;
            }

            try (
                    PreparedStatement statement =
                            connection.prepareStatement(sql)
            ) {

                statement.setInt(
                        1,
                        gameId
                );

                statement.setInt(
                        2,
                        playerId
                );

                statement.setString(
                        3,
                        drawingData
                );

                statement.executeUpdate();
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error saving drawing."
            );

            e.printStackTrace();
        }
    }


    public static List<String> loadDrawings(
            int gameId
    ) {

        List<String> drawings =
                new ArrayList<>();

        String sql =
                "SELECT drawing_data " +
                        "FROM drawings " +
                        "WHERE game_id = ? " +
                        "ORDER BY drawing_id";

        try (
                Connection connection =
                        DataBaseConnection.connect()
        ) {

            if (connection == null) {
                return drawings;
            }

            try (
                    PreparedStatement statement =
                            connection.prepareStatement(sql)
            ) {

                statement.setInt(
                        1,
                        gameId
                );

                try (
                        ResultSet resultSet =
                                statement.executeQuery()
                ) {

                    while (resultSet.next()) {

                        drawings.add(
                                resultSet.getString(
                                        "drawing_data"
                                )
                        );
                    }
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return drawings;
    }
}